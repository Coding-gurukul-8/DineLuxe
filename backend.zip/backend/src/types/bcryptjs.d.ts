declare module 'bcryptjs';
